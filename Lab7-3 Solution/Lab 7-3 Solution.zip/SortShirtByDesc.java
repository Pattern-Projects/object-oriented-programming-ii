package com.example.generics;

import java.util.Comparator;

public class SortShirtByDesc implements Comparator<Shirt> {

    @Override
    public int compare(Shirt shirt1, Shirt shirt2) {
        /*
        java.lang.String::public int compareTo(String anotherString)
        Returns:
            - the value 0 if the argument string (shirt2.getDescription()) is equal 
              to this (shirt1.getDescription()) string; 
            - a value less than 0 if this string is lexicographically less than the string argument;
            - a value greater than 0 if this string is lexicographically greater than 
              the string argument.
        */
        
        return shirt1.getDescription().compareTo(shirt2.getDescription());
    }
}
