package com.example.generics;

import java.util.Comparator;

public class SortShirtByCount implements Comparator<Shirt> {

    @Override
    public int compare(Shirt shirt1, Shirt shirt2) {
        Long count1 = new Long(shirt1.getCount());
        Long count2 = new Long(shirt2.getCount());

        /*
        java.lang.Long::public int compareTo(Long anotherLong)
            Compares two Long objects numerically.
            Parameters:
                anotherLong - the Long to be compared. 
            Returns:
                the value 0 if this Long (count1) is equal to the argument Long (count2); 
                a value less than 0 if this Long is numerically less than the argument Long; 
                and a value greater than 0 if this Long is numerically greater than the 
                argument Long (signed comparison).
        */
        return count1.compareTo(count2);
    }
}
